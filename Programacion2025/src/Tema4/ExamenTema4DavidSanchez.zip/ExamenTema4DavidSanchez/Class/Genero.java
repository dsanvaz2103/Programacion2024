package Tema4.ExamenTema4DavidSanchez.Class;

public enum Genero {
    Masculino,Femenino,Otro;
}
