package Tema4.ExamenTema4DavidSanchez.Class;

// Ejemplo de INTERFAZ
public interface Evaluable {
    // Metodo calificar;
    double calificar();
}
